// Minimal Telegram bot for Cloud Run (webhook)
import express from "express";
import { Telegraf, Markup } from "telegraf";

const {
  BOT_TOKEN,          // ваш токен бота
  ADMIN_CHAT_ID,      // ваш Telegram ID для службових сповіщень
  SECRET_TOKEN = "secret123" // довільний секрет для вебхука
} = process.env;

if (!BOT_TOKEN) throw new Error("BOT_TOKEN is required");

const bot = new Telegraf(BOT_TOKEN);
const app = express();

// 🔒 приймаємо лише валідні запити Telegram
app.use(express.json());

// --- BOT LOGIC ---
bot.start(async (ctx) => {
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback("🇺🇦 Українська", "lang:uk"), Markup.button.callback("🇷🇺 Русский", "lang:ru")],
    [Markup.button.callback("🇬🇧 English", "lang:en"), Markup.button.callback("🇩🇪 Deutsch", "lang:de")],
    [Markup.button.callback("🇸🇦 العربية", "lang:ar")]
  ]);
  await ctx.reply("Обeріть мову / Choose language:", kb);
});

bot.action(/^lang:(uk|ru|en|de|ar)$/i, async (ctx) => {
  const codes = { uk:"Українська", ru:"Русский", en:"English", de:"Deutsch", ar:"العربية" };
  const lang = ctx.match[1];
  await ctx.answerCbQuery();
  await ctx.editMessageText(`✅ Мову збережено: ${codes[lang]}.\nБот працює стабільно ✅`);
  if (ADMIN_CHAT_ID) {
    await ctx.telegram.sendMessage(
      ADMIN_CHAT_ID,
      `🆕 Новий користувач: @${ctx.from?.username || "-"}\nLang: ${codes[lang]}`
    );
  }
  await ctx.reply("✍️ Опишіть, будь ласка, вашу проблему або виберіть категорію.");
});

// --- WEBHOOK WIRING ---
app.get("/", (_req, res) => res.status(200).send("OK")); // healthcheck

// натиснете цей URL один раз після деплою, щоб зареєструвати вебхук
app.get("/set-webhook", async (req, res) => {
  try {
    const baseUrl = `${req.protocol}://${req.get("host")}`;
    const url = `${baseUrl}/webhook/${SECRET_TOKEN}`;
    await bot.telegram.setWebhook(url);
    res.status(200).send(`Webhook set to: ${url}`);
  } catch (e) {
    console.error(e);
    res.status(500).send(String(e));
  }
});

// сам endpoint для Telegram
app.post(`/webhook/${SECRET_TOKEN}`, (req, res) => {
  bot.handleUpdate(req.body);
  res.status(200).send("OK");
});

// локально (на Cloud Run не потрібно) — в режимі poll не запускаємо
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Listening on ${PORT}`);
});